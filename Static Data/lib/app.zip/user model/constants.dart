const String NAME = 'Name';
const String AGE = 'Age';
const String EMAIL = 'Email';
const String PHONE = 'Phone';
const String CITY = 'City';
const String DOB = 'Dob';
const String GENDER = 'Gender';
const String HOBBIES = 'Hobbies';
const String PASSWORD = 'Password';
const String CON_PASS = 'Confirm_password';
const String EDUCATION = 'Education';
const String OCCUPATION = 'Occupation';
const String WORK_PLACE = 'Work_place';
const String INCOME = 'Income';

const String ISLIKED = 'isLiked';
