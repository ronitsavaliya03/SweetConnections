import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:matrimonial_app/user%20model/constants.dart';
import 'package:matrimonial_app/user%20model/user.dart';
import 'package:matrimonial_app/screens/add_user.dart';
import 'package:matrimonial_app/screens/information.dart';

User user = User();
List<Map<String, dynamic>> favoriteUsers=[];

class UserList extends StatefulWidget {
  const UserList({super.key});

  @override
  State<UserList> createState() => _UserListState();
}

class _UserListState extends State<UserList> {
  final TextEditingController searchDetails = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Candidate List",
          style: TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold,),
        ),
        backgroundColor: Color.fromARGB(255, 136, 14, 79),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            SizedBox(
              height: 20,
            ),
            TextFormField(
              controller: searchDetails,
              onChanged: (value) {
                user.searchDeatil(searchData: value);
                setState(() {});
              },
              decoration: InputDecoration(
                  hintText: 'Search people & places',
                  prefixIcon: Icon(
                    Icons.search_rounded,
                    size: 25,
                  ),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12))),
            ),
            SizedBox(
              height: 15,
            ),
            user.display().isEmpty ||
                    (searchDetails.text != '' && user.searchResultList.isEmpty)
                ? Expanded(
                    child: Center(
                        child: Text(
                      'No Candidate Found',
                      style: TextStyle(color: Colors.grey, fontSize: 15),
                    )),
                  )
                : Expanded(
                    child: ListView.builder(
                      itemBuilder: (BuildContext context, int index) {
                        print(':::LISTVIEW ITEM BUILDER CALLED:::$index');
                        return userCard(index);
                      },
                      itemCount: searchDetails.text == ''
                          ? user.userList.length
                          : user.searchResultList.length,
                    ),
                  )
          ],
        ),
      ),
    );
  }

  Widget userCard(i) {
    return InkWell(
      onTap:  () {
        int userIndex = searchDetails.text == '' ? i : user.userList.indexOf(user.searchResultList[i]);

        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => Information(i: userIndex),
        ));
      },
      child: Card(
        elevation: 10,
        child: Column(
          children: [
            ListTile(
              leading: Icon(Icons.person, color: Colors.pinkAccent, size: 30,),
              // trailing: Wrap(
              //   alignment: WrapAlignment.center,
              //   direction: Axis.horizontal,
              // ),
              title: Text(
                searchDetails.text == ''
                    ? '${user.userList[i][NAME]}'
                    : '${user.searchResultList[i][NAME]}',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                searchDetails.text == ''
                    ? '${user.userList[i][EMAIL]} | ${user.userList[i][CITY]}'
                    : '${user.searchResultList[i][EMAIL]} | ${user.searchResultList[i][CITY]}',
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: (() {
                      if (user.userList[i][ISLIKED] == false) {
                        setState(() {
                          user.userList[i][ISLIKED] = true;
                        });
                      } else {
                        showDialog(
                          context: context,
                          builder: (context) {
                            return CupertinoAlertDialog(
                              title: Text('Unlike'),
                              content: Text('Are you sure want to unlike?'),
                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                    setState(() {
                                      user.userList[i][ISLIKED] = false;
                                    });
                                  },
                                  child: Text('Yes'),
                                ),
                                TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  child: Text('No'),
                                )
                              ],
                            );
                          },
                        );
                      }
                    }),
                    icon: !user.userList[i][ISLIKED]
                        ? Icon(
                      Icons.favorite_border,
                      color: Colors.grey,
                    )
                        : Icon(
                      Icons.favorite,
                      color: Colors.red,
                    )),
                IconButton(
                    onPressed: (() {
                      print(user.userList[i][DOB]);
                      Navigator.of(context)
                          .push(MaterialPageRoute(
                          builder: (context) => AddEditScreen(
                            data: user.userList[i],
                          )))
                          .then((value) {
                        if (value != null) {
                          user.userList[i] = value;
                          setState(() {});
                        }
                      });
                    }),
                    icon: Icon(Icons.edit)),
                IconButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return CupertinoAlertDialog(
                          title: Text('DELETE'),
                          content: Text('Are you sure want to delete?'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                searchDetails.text == ''
                                    ? user.deleteUser(id: i)
                                    : user.deleteUserFromSearchList(index: i);

                                Navigator.pop(context);
                                setState(() {});
                              },
                              child: Text('Yes'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('No'),
                            )
                          ],
                        );
                      },
                    );
                  },
                  icon: Icon(
                    Icons.delete,
                    color: Colors.red,
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
