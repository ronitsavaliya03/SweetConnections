import 'package:flutter/material.dart';
import 'package:matrimonial_app/user%20model/constants.dart';
import 'package:matrimonial_app/screens/user_list.dart';

class Information extends StatelessWidget {
  dynamic i;
  Information({super.key, this.i});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Information of ${user.userList[i][NAME]}", style: TextStyle(fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold,),),
        backgroundColor: const Color.fromARGB(255, 136, 14, 79),
      ),
      body: Card(
        elevation: 4,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Basic Information",style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold, color: Color.fromARGB(255, 136, 14, 79)),),
                const SizedBox(height: 10),
                _buildInfoRow(
                    Icons.person,
                    "Full Name",
                    '${user.userList[i][NAME]}'),
                const Divider(thickness: 1, height: 20),
                _buildInfoRow(
                    Icons.location_city,
                    "City",
                    '${user.userList[i][CITY]}'),
                const Divider(thickness: 1, height: 20),
                _buildInfoRow(
                    Icons.phone,
                    "Phone Number",
                    '${user.userList[i][PHONE]}'),
                const Divider(thickness: 1, height: 20),
                _buildInfoRow(
                    Icons.email,
                    "Email",
                    '${user.userList[i][EMAIL]}'
                ),
                const Divider(thickness: 1, height: 20),
                _buildInfoRow(
                    Icons.date_range_outlined,
                    "Date of birth",
                    '${user.userList[i][DOB]}'
                ),
                const Divider(thickness: 1, height: 20),
                _buildInfoRow(
                    (user.userList[i][GENDER])=='Male' ? Icons.male: Icons.female,
                    "Gender",
                    '${user.userList[i][GENDER]}'
                ),
                const Divider(thickness: 1, height: 20),
                _buildInfoRow(
                    Icons.format_align_left,
                    "Hobbies",
                    '${user.userList[i][HOBBIES]}'
                ),
                const SizedBox(height: 30),
                Text("Educational & Professional Details",style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold, color: Color.fromARGB(255, 136, 14, 79)),),
                const SizedBox(height: 10),
                _buildInfoRow(
                    Icons.school,
                    "Education Qualification",
                    '${user.userList[i][EDUCATION]}'
                ),
                const Divider(thickness: 1, height: 20),
                _buildInfoRow(
                    Icons.work,
                    "Occupation & Job Role",
                    '${user.userList[i][OCCUPATION]}'
                ),
                const Divider(thickness: 1, height: 20),
                _buildInfoRow(
                    Icons.apartment,
                    "Company Name & Work Location",
                    '${user.userList[i][WORK_PLACE]}'
                ),
                const Divider(thickness: 1, height: 20),
                _buildInfoRow(
                    Icons.attach_money,
                    "Annual Income",
                    '${user.userList[i][INCOME]}'
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: Colors.pinkAccent),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
