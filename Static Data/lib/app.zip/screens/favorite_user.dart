import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:matrimonial_app/screens/user_list.dart';
import 'package:matrimonial_app/user%20model/constants.dart';
import 'package:matrimonial_app/user%20model/user.dart';
import 'package:matrimonial_app/screens/information.dart';

class FavoriteUserList extends StatefulWidget {
  const FavoriteUserList({super.key});

  @override
  State<FavoriteUserList> createState() => _FavoriteUserListState();
}

class _FavoriteUserListState extends State<FavoriteUserList> {
  final TextEditingController searchController = TextEditingController();
  List<Map<String, dynamic>> filteredUsers = [];

  @override
  void initState() {
    super.initState();
    // Initialize filteredUsers with only favorite users
    filteredUsers = user.userList.where((u) => u[ISLIKED] == true).toList();
  }

  void searchUsers(String query) {
    setState(() {
      if (query.isEmpty) {
        filteredUsers = user.userList.where((u) => u[ISLIKED] == true).toList();
      } else {
        filteredUsers = user.searchDeatil(searchData: query)
            .where((u) => u[ISLIKED] == true)
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Favorite Candidates",
          style: TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Color.fromARGB(255, 136, 14, 79),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            SizedBox(height: 20),
            TextFormField(
              controller: searchController,
              onChanged: searchUsers,
              decoration: InputDecoration(
                hintText: 'Search favorite candidates...',
                prefixIcon: Icon(Icons.search, size: 25),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            SizedBox(height: 15),
            filteredUsers.isEmpty
                ? Expanded(
              child: Center(
                child: Text(
                  'No Favorite Candidates',
                  style: TextStyle(color: Colors.grey, fontSize: 15),
                ),
              ),
            )
                : Expanded(
              child: ListView.builder(
                itemCount: filteredUsers.length,
                itemBuilder: (context, index) {
                  return userCard(index);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget userCard(int index) {
    var favoriteUser = filteredUsers[index];

    return InkWell(
      onTap: () {
        int userIndex = user.userList.indexOf(favoriteUser);
        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => Information(i: userIndex),
        ));
      },
      child: Card(
        elevation: 10,
        child: Column(
          children: [
            ListTile(
              leading: Icon(Icons.person, color: Colors.pinkAccent, size: 30),
              title: Text(
                '${favoriteUser[NAME]}',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '${favoriteUser[EMAIL]} | ${favoriteUser[CITY]}',
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return CupertinoAlertDialog(
                          title: Text('Unlike'),
                          content: Text('Are you sure want to unlike?'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                                setState(() {
                                  favoriteUser[ISLIKED] = false;
                                  searchUsers(searchController.text);
                                });
                              },
                              child: Text('Yes'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('No'),
                            )
                          ],
                        );
                      },
                    );
                  },
                  icon: Icon(Icons.favorite, color: Colors.red),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
